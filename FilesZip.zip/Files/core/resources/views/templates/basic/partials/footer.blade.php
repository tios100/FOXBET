<div class="container-fluid mt-auto px-0">
    <div class="footer footer--dark">
        <div class="container">
            @include($activeTemplate . 'partials.footer_top')
        </div>
    </div>

    <div class="footer-bottom footer-bottom--dark">
        <div class="container">
            @include($activeTemplate . 'partials.footer_bottom')
        </div>
    </div>
</div>
